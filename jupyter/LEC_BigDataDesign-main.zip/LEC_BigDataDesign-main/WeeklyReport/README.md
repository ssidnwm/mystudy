### Weekly Report
- Upload your weekly report
- Use this sample .ipynb file (BigDataDesign_weekly.ipynb)
