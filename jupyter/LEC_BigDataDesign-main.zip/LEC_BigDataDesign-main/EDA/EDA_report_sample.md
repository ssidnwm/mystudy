# Exploratory Data Analysis 
### - StudentID: 
### - Name:
### - 1st Major:
### - 2nd Major:
<br>

<i>Brief summary of your proposed project idea. </i>

<br><br>
## 1. Data overview <br>
Descriptives statistics on overall data (sample size, number of variables, data type, data range, distribution, etc.)  <br> 

<br><br>
## 2. Univariate analysis <br>
Presentation of key variables from various aspects

### 2.1 (ex) Variable 1 <br>
~~
<figure>
  <img src="bts_google.png" alt="BTS Google Trend"/>
  <figcaption>Figure 1. BTS Google Trend</figcaption>
</figure>

### 2.2 (ex) Variable 2 <br>
~~

<br><br>
## 3. Multivariate analysis <br>
Presenation of hidden patterns between variables (correlation, clustering, etc.)

### 3.1 (ex) Correlation <br>
~~
### 3.2 (ex) Clustering <br>
~~

<br><br>
## 4. Suggestion <br>
Based on the insights you obtained from the previous stages, propose the potential project idea.
