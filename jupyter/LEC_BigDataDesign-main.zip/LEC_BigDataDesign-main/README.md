# LEC_BigDataDesign 빅데이터종합설계
Welcome to Big Data Capstone Design.

This repository contains all the files used during the lecture. 
